package LABSHEET1;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

public class VMTranslator{
    public static void main(String[] args) {
        ArrayList<String> asm_code = new ArrayList<>();
        String filename = "D:\\SEM2\\22AIE113-Elements of Computing Systems -2\\LABSHEET1\\BasicTest.vm";
        try (BufferedReader read = new BufferedReader(new FileReader(filename))) {
            String contents;
            while ((contents = read.readLine()) != null) {
                contents = contents.trim(); // Trim the contents
                if (contents.startsWith("//") || contents.isEmpty()) {
                    continue;
                } else {
                    if (contents.startsWith("push")) {
                        List<String> splitted_contents = split(contents);
                        String memorysegments = splitted_contents.get(1);
                        String i = splitted_contents.get(2);
                        asm_code.add("//" + contents);
                        if ("static".equals(memorysegments)) {
                            asm_code.add(VmConstructor.pushStatic(i));
                        } else if ("local".equals(memorysegments)) {
                            asm_code.add(VmConstructor.pushLCL(i));
                        } else if ("constant".equals(memorysegments)) {
                            asm_code.add(VmConstructor.pushconstant(i));
                        } else if ("argument".equals(memorysegments)) {
                            asm_code.add(VmConstructor.pushARG(i));
                        } else if ("that".equals(memorysegments)) {
                            asm_code.add(VmConstructor.pushThat(i));
                        } else if ("this".equals(memorysegments)) {
                            asm_code.add(VmConstructor.pushThis(i));
                        } else if ("temp".equals(memorysegments)) {
                            asm_code.add(VmConstructor.pushtemp(i));
                        } else if ("pointer".equals(memorysegments)) {
                            asm_code.add(VmConstructor.pushpointer(i));
                        }
                    } else if (contents.startsWith("pop")) {
                        List<String> splitted_contents = split(contents);
                        String memorysegments = splitted_contents.get(1);
                        String i = splitted_contents.get(2);
                        asm_code.add("//" + contents);
                        if ("static".equals(memorysegments)) {
                            asm_code.add(VmConstructor.popStatic(i));
                        } else if ("local".equals(memorysegments)) {
                            asm_code.add(VmConstructor.popLCL(i));
                        } else if ("argument".equals(memorysegments)) {
                            asm_code.add(VmConstructor.popARG(i));
                        } else if ("that".equals(memorysegments)) {
                            asm_code.add(VmConstructor.popThat(i));
                        } else if ("this".equals(memorysegments)) {
                            asm_code.add(VmConstructor.popThis(i));
                        } else if ("temp".equals(memorysegments)) {
                            asm_code.add(VmConstructor.popTemp(i));
                        } else if ("pointer".equals(memorysegments)) {
                            asm_code.add(VmConstructor.popPointer(i));
                        }
                    } else {
                        switch (contents) {
                            case "add":
                                asm_code.add("//" + contents);
                                asm_code.add(VmConstructor.add());
                                break;
                            case "neg":
                                asm_code.add("//" + contents);
                                asm_code.add(VmConstructor.neg());
                                break;
                            case "sub":
                                asm_code.add("//" + contents);
                                asm_code.add(VmConstructor.sub());
                                break;
                            case "eq":
                                asm_code.add("//" + contents);
                                asm_code.add(VmConstructor.eq());
                                break;
                            case "not":
                                asm_code.add("//" + contents);
                                asm_code.add(VmConstructor.not());
                                break;
                            case "or":
                                asm_code.add("//" + contents);
                                asm_code.add(VmConstructor.or());
                                break;
                            case "and":
                                asm_code.add("//" + contents);
                                asm_code.add(VmConstructor.and());
                                break;
                            case "lt":
                                asm_code.add("//" + contents);
                                asm_code.add(VmConstructor.lt());
                                break;
                            case "gt":
                                asm_code.add("//" + contents);
                                asm_code.add(VmConstructor.gt());
                                break;
                        }
                    }
                }
            }
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("D:\\SEM2\\22AIE113-Elements of Computing Systems -2\\LABSHEET1\\VM_Output.asm"))) {
                for (String print : asm_code) {
                    if (print == null) {
                        continue;
                    }
                    writer.write(print);
                    writer.newLine();
                    System.out.println("Reached Here");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<String> split(String i) {
        return Arrays.asList(i.split("\\s+"));
    }
}
